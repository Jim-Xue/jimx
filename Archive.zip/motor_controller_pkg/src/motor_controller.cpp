#include "rclcpp/rclcpp.hpp"
#include "rclcpp/publisher.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "vision_msgs/msg/detection2_d_array.hpp"
#include <chrono>
#include <iostream>
#include <string>

using std::placeholders::_1;
using namespace std;
using namespace std::chrono_literals;

class Control : public rclcpp::Node
{
public:
  Control()
  : Node("control")
  {
    subscription_ = this->create_subscription<vision_msgs::msg::Detection2DArray>(
      "detections_output", 10, std::bind(&Control::subscriber_callback, this, _1));

    publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("cmd_vel", 10);

  }

private:
  void subscriber_callback(const vision_msgs::msg::Detection2DArray::SharedPtr detection_p) {
    // Initialize variables to track the most prominent person
    double max_score = 0.0;
    const vision_msgs::msg::Detection2D* selected_detection = nullptr;

    for (const auto& detection : detection_p->detections) {
      for (const auto& result : detection.results) {
        const auto& hypothesis = result.hypothesis;
        if (hypothesis.class_id == "person" && hypothesis.score > max_score) {
          max_score = hypothesis.score;
          selected_detection = &detection;
        }
      }
    }

    // Publish control commands based on the selected detection (person)
    if (max_score > 0.0) {
      // Calculate the offset of the person's bounding box center from the center of the frame
      double bbox_center_x = selected_detection->bbox.center.position.x;
      double frame_center_x = 320 /* Calculate the center of the camera frame */;
      double offset = bbox_center_x - frame_center_x;

      // Define threshold for staying stationary and turning directions
      double offset_threshold_stay = 10.0; // Threshold for staying stationary

      // Publish control commands based on the offset direction
      geometry_msgs::msg::Twist control_cmd;
      if (offset < -offset_threshold_stay) {
        // Person is moving towards the left side of the frame, turn right
        control_cmd.linear.x = 0.0;
        control_cmd.angular.z = -0.5 /* Calculate angular velocity for turning right */;
      } else if (offset > offset_threshold_stay) {
        // Person is moving towards the right side of the frame, turn left
        control_cmd.linear.x = 0.0;
        control_cmd.angular.z = 0.5 /* Calculate angular velocity for turning left */;
      } else {
        // Person is in the center of the frame, stay stationary
        control_cmd.linear.x = 0.0;
        control_cmd.angular.z = 0.0;
      }
      publisher_->publish(control_cmd);
    } else {
      // No person detected, stop tracking
      // Publish stop command or other appropriate action
      geometry_msgs::msg::Twist stop_cmd;
      stop_cmd.linear.x = 0.0;
      stop_cmd.angular.z = 0.0;
      publisher_->publish(stop_cmd);
    }
  }

  rclcpp::TimerBase::SharedPtr timer_;
  rclcpp::Subscription<vision_msgs::msg::Detection2DArray>::SharedPtr subscription_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Control>());
  rclcpp::shutdown();
  return 0;
}
