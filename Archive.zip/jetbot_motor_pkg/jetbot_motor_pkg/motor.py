import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from adafruit_motorkit import MotorKit

class Motor(Node):
        def __init__(self):
                super().__init__('motor_node')
                self.kit = MotorKit()
                self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
                self.get_logger().info('MotorControlNode started')

        def set_and_publish_velocities(self):
                # Get user input for linear and angular velocities
                linear_x = float(input("Enter linear velocity: "))
                angular_z = float(input("Enter angular velocity: "))
                 
                # Create and publish Twist message
                twist_msg = Twist()
                twist_msg.linear.x = linear_x
                twist_msg.angular.z = angular_z
                self.publisher_.publish(twist_msg)
                 
                # Log the published velocities
                self.get_logger().info(f'Published velocities - Linear: {linear_x}, Angular: {angular_z}')

                # Command motors based on input (simplified for demonstration)
                self.command_motors(linear_x, angular_z)

        def command_motors(self, linear, angular):
                # Convert linear and angular velocities to motor commands
                left_motor_speed = linear - angular
                right_motor_speed = linear + angular
                # Ensure the values are within [-1.0, 1.0] for MotorKit
                self.kit.motor1.throttle = max(min(left_motor_speed, 1.0), -1.0)
                self.kit.motor2.throttle = max(min(right_motor_speed, 1.0), -1.0)

def main(args=None):
	rclpy.init(args=args)
	motor_node = Motor()
    
	try:
            	while rclpy.ok():
                	motor_node.set_and_publish_velocities()
                	rclpy.spin_once(motor_node, timeout_sec=0.1)
	except KeyboardInterrupt:
    	        pass
    
	motor_node.destroy_node()
	rclpy.shutdown()

if __name__ == '__main__':
	main()

